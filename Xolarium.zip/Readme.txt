
 ,ggg,          ,gg                                                                                
dP"""Y8,      ,dP'               ,dPYb,                                                            
Yb,_  "8b,   d8"                 IP'`Yb                                                            
 `""    Y8,,8P'                  I8  8I                         gg                                 
         Y88"                    I8  8'                         ""                                 
        ,888b         ,ggggg,    I8 dP    ,gggg,gg   ,gggggg,   gg   gg      gg   ,ggg,,ggg,,ggg,  
       d8" "8b,      dP"  "Y8ggg I8dP    dP"  "Y8I   dP""""8I   88   I8      8I  ,8" "8P" "8P" "8, 
     ,8P'    Y8,    i8'    ,8I   I8P    i8'    ,8I  ,8'    8I   88   I8,    ,8I  I8   8I   8I   8I 
    d8"       "Yb, ,d8,   ,d8'  ,d8b,_ ,d8,   ,d8b,,dP     Y8,_,88,_,d8b,  ,d8b,,dP   8I   8I   Yb,
  ,8P'          "Y8P"Y8888P"    8P'"Y88P"Y8888P"`Y88P      `Y88P""Y88P'"Y88P"`Y88P'   8I   8I   `Y8

by Soheilshahrab
Created on: 9:31 PM
Version: 1.0

Bugs: 
1. Random chance of crashes (known, uncommon, happens more commonly when you have a lot of application and the CPU is more active).
2. Rendering issues (unsure/unknown, rare, happens slightly more commonly when you are in a older version of Windows (Windows 7/8/8.1 Aero or newer is recommended) (it never happened for me)

Ever wished for an accelerated and efficient safe GDI application? Here you Go!
It offers multi-threaded HSV RGBQUAD with graceful termination, and even other effects that are fast!
Enjoy!

Credits to JhoPro (a.k.a. ArTicZera) for the original HSV shader.
Credits to pankoza for the basic BitBlt's and bytebeat engine.
Credits to N17Pro3426 (@nazar7346) for the faster screen disortener (Fast Sine)
Credits to ChatGPT (helper) for the HSV shader optimization (multi-threaded rendering, optimized/simplified HSV converters)
Credits to Soheilshahrab (creator) for the graceful exiting, bytebeats, HSV shader custom effects & ideas.

Ask N17Pro3426 (@nazar7346) to get this GDI application!