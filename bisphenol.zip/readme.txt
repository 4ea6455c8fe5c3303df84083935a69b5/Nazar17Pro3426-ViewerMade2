bisphenol.exe by malsteve527
https://www.youtube.com/channel/UCvN8heP-VU1O1AsQp5CykfA

This is a destructive malware that will harm your computer.
For educational purposes and it should be run ONLY in a virtual machine.
I'm NOT responsible for ANY damage.
The safe version has only GDI payloads.

Credits to nanochess for the MBR.
Enjoy!