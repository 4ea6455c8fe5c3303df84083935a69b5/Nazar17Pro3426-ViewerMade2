This malware is created by _inc0gnit0
Subscribe to him on YouTube!
https://www.youtube.com/@_inc0gnit0