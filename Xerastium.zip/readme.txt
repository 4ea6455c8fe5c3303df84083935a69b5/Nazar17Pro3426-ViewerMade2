__  __                  _   _                 
\ \/ /___ _ __ __ _ ___| |_(_)_   _ _ __ ___  
 \  // _ \ '__/ _` / __| __| | | | | '_ ` _ \ 
 /  \  __/ | | (_| \__ \ |_| | |_| | | | | | |
/_/\_\___|_|  \__,_|___/\__|_|\__,_|_| |_| |_|

This will be my last malware for this time. I got burnt out on making malwares, so this
will be the final one. Anyway this malware shouldn't be ran on a real PC (didn't have
time to make a safe version), I'm not responsible for any damages caused by this malware,
you have been warned.

This malware has 24 payloads and 20 sounds.
There's also a payload that only activates on a specific date (good luck finding it :D)

Download link will not be released as I'm no longer making public malwares again.

Also I forgot to mention, there's flashing lights and loud sounds, so don't run it if
you're sensitive to flashing lights and loud sounds.

Discord: AG5516#7432