Exromentium.exe
There is 20 GDI effects 
Run it on Windows 7-11
If you want to test it, please run the safe version
Don't run the destructive version, because it can cause data loss
-------------------------------------
Made by RikGDI
https://www.youtube.com/@win32.rikgdi
https://www.github.com/rikgdi
--------------------------------------