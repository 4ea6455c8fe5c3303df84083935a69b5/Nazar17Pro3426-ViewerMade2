﻿Lloviu.exe

Malware name: Lloviu
Malware type: Trojan
Damage rate: Destructive
Works best in: Windows 2000 or newer
Made in: Dev-C++
Do NOT download it in your real PC, I'm NOT responsible for ANY damages!