++++++++++++ooooooo++++++++++++++++//////+++///////::://////////++++ooossssssssssooossssssooooossyys
oo+++++++/++++++++//////////////////::/://///:::::::::::::::///////////+++/////::::/::::::::://+shhh
/////////:///::::::://////+++++++ooo++++++ooooosssyyyyhhhys/:::::::::::////:::::://////////////+syhh
////+oo+++oosssoossyhhhdddmmmmmmmmmmmmmddddddmmmmmNNNNNNNmdo//++++++++ooooooooooooooooooossooooossss
yyyyhdddhddmmmmdddmmNNNNNMMMMMMMMMMMMNNNNNNNNNNNNNMMMMMMMNdo/+osyyyyyyyyyyyyyyyssssssysyyyyysssso+++
ddddmNNmmmmNNmmmmmNNNMMMMMMMMMMMMMMMMMMMNNNNNNNNNNMMMMMMMNdo/osyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyso/::
mdddmmmmdmmmmmmmmmNNNMMMMMMMMMMMMMMMMMMMMNNNNNNNNNMMMMMMNNdo/+osyyyyyyyyhhhhhhhhyyyhhhhhhhhyyyyso/::
dddddmmddddddddmmmNNNMMMMMMMMMMMMMMMMMMMMMNNNNNNNNNMMMMMNNdo/+osyyyyyyyyyhhhhhhhhhhhhhhhhhhhyyyss+/:
dddddmmddddddddddmNNNMMMMMMMMMMMMMMMMMMMMNNNNNNNNNNMMMMMNmdo/+osyyhyyssossyyhhhhhyyyhhhhhhhyyyssssoo
dddddmmmmmmdddhddmNNMMMMMMMMMMMMNMMMMMMMMNNNNNNNNNNMMMMNNmh+:+osyyhyso+//++osyhhhyssssssyyyyyssssyyy
dddddmmmmmmddhhddmNNMMMMMMMMMMMMNMMMMMMMMMNNNNNNNNNMMNNNmds//+osyyyys+/::://osyyyys+////+osssssyyyyy
dddhddmmdddhhddddmNNMMMMMMMMMMMNNMMMMMMMMMNNNNNNNmNNMNmoo+/::/+ooooo+//::::/+osyso+/:::::/+oossyyyyy
dddhhhhhyyyhhdddmmNNNMMMMMMMMMMNNMMMMMMMMMNNNNNmo:hNms-.--........`.-.......ossysso++//+++ossssssyyy
dddhhhysssyhdddddmmNNMMMMMMMMMMNNNMMMMMMMMNNNNy+/.-/.``-/--.....-``````````.syyyyyyyssyyyyyyysosssyy
dddddhysosyhdddddmmNNMMMMMMMMMMMNNMMMMMMMNNmmNo/.``````..`````````  ```````/yyyyyyyhhhhhhhyyssssssss
dddddhhsosyhddddddmNNNNNNMMMMMMMNNMMMNmmdhhhhhy+/::-.```..`````.-``-sysssssyyyyyyyyyyyyyyyysssssssss
dddddhysosyyhhhhhdmmNNNNNMMMMMMNNmddhdddddddmdho///+++/:-.`..``````+ssssoossssssssssssssoossssssssss
dddddhysosyyyhyyshdmNNNmdhs+//ssyyyyhddddddddhs/:::://////++://`.:/+++////////////+++++oooosssssssss
ddddhysssyyyhhhhyso+/:----..-..-:oyhhdhhhhhdddyo//--:---:///:::-+++++/////////////+++++ooooossssssss
dmddhyysyyyyyyo/:.`..............-:oyyhhhhhhddyo/o/:-:::+o+:--:/+++++///////++++++//+++++oooossssoos
mmddhyso+/:...-:.```..```.```...`.--/oyyssyysoy/:::://::///+:://+++/////////+++++//////++++ooooooooo
yyso+:...--...-.``` ...```````..`...--/+ossyyo+:::--:///://+--:::::::::::--::::::::::::://///++++++/
:---.``.--..`````````..```````..``.`.--:/++syy+-::/-.::/oyyo:---:::::---.....------::::::///////////
--.```.--.```````````.`````````.``...-----:/s+::-:::-/ohdhyo:-://////:--.....---::://///++++++++++++
..````...````````` `````````  ````.---------./:::-::yddhyso/--:/++++/::-.....--::///++++oooooooooooo
``````..``````````````````````````.-.------..-:::/+hmdy++//::://+++++/:--...--:://++oooossssssssssss
`````````````````````````` ````````` ``./sssso++smNNmhs/++//:-:////////:-...--::/++oossssssyyyyyyyyy
```````````````````````````` ``````````-sNNmmmmmNNNmmho++++/-----:::://:-.....--://++ooossssyyyyyyyy
```````````````````````````````````.:+ymNNNNmmNNNNNNmho+oo+/:-----::////:-..```...--::///+++ooosssss
```````````````````````````````---:+yddmNNNNNNNNNNNNmhoooo+/:----::///::--..````````....---:::::////
``````````````````````````-:///////:/shddmmddmmmmNmmdyoooo+/:---::////::---...````````````...-------
````````````````````````-/++oo++o+///+osyysoooossssssooooo+/:--:://+++++//////::::---....``.-:+oooo+
``.`````````````````.:/++++ooooooo++++syyyo/-```.`.-:/ooso+/:--:://++oo+++++ooo+++++////:-.`.:/+ooss
.......```````.-:+oyyo+/////+oooooooooyhhhys/-`````.:/ooso+/:::://++++++++++ooooooo+++++:-.``..-::/+

Malware name: Tyul
Damage rate: Destructive
Malware type: Trojan
Application: Win32
-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
WARNING!
Before you running the trojan you must to install C++ Runtime 2015-2019 x86 or even else the trojan will NOT work!
But if you run it, it will popup the message as well by clicking YES, you see flashing lights.

So... Enjoy the trojan!

Created by JuduardoKid1209