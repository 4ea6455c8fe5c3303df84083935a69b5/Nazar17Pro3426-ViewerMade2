Conducive.exe
This is a joke malware created by AI
Idea by me and my real-life friend.
It was about the AI users that want to replace jobs.