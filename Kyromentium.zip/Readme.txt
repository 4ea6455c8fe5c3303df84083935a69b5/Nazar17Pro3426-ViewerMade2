Kyromentium.exe
There is 20 GDI effects 
Run it on Windows 7-11
-------------------------------------
Made by RikGDI
https://www.youtube.com/@win32.rikgdi
https://www.github.com/rikgdi
--------------------------------------