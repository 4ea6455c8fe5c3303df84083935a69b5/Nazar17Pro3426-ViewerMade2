███╗░░██╗███████╗███╗░░░███╗███████╗░██████╗██╗░██████╗░░░███████╗██╗░░██╗███████╗
████╗░██║██╔════╝████╗░████║██╔════╝██╔════╝██║██╔════╝░░░██╔════╝╚██╗██╔╝██╔════╝
██╔██╗██║█████╗░░██╔████╔██║█████╗░░╚█████╗░██║╚█████╗░░░░█████╗░░░╚███╔╝░█████╗░░
██║╚████║██╔══╝░░██║╚██╔╝██║██╔══╝░░░╚═══██╗██║░╚═══██╗░░░██╔══╝░░░██╔██╗░██╔══╝░░
██║░╚███║███████╗██║░╚═╝░██║███████╗██████╔╝██║██████╔╝██╗███████╗██╔╝╚██╗███████╗
╚═╝░░╚══╝╚══════╝╚═╝░░░░░╚═╝╚══════╝╚═════╝░╚═╝╚═════╝░╚═╝╚══════╝╚═╝░░╚═╝╚══════╝

Created by: Lizkit
Coding language: C++
Programs used: Visual Studio 2022 v17.12.4, Dev-C++
Supported OS: Windows XP and over.
This program will NOT work with previous versions.

This program is malicious and can cause significant damage to your system.
Upon executing it, you will be greeted with a warning to confirm your decision.

This program has flashing lights and loud noises.

Enjoy :)