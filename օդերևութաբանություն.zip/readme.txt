օդերևութաբանություն (ōderewutʻabanutʻyun)
input name: 0tyr&ov;abanov;3ovn
by CriticForInterpreting

A black hole malware