Dykyromentium.exe
There is 39 GDI effects 
Run it on Windows 7-11
Run the destructive version as administrator to see the porper destruction
It's for safety reasons
-------------------------------------
Made by RikGDI and Cee-Jay
https://www.youtube.com/@win32.rikgdi
https://www.github.com/rikgdi
https://www.youtube.com/@cee-jay0900
https://www.github.com/Cee-Jay0900
MBR by Gabolate
https://www.youtube.com/@GabolateAnime
https://www.github.com/Gabolate
--------------------------------------