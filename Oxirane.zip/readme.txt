Oxirane.exe by malsteve527

This is a malware!
It will overwrite your MBR (Master Boot Record).
I'm NOT responsible for ANY damage.

Credits to wipet for HSL shaders.
Enjoy this malware!