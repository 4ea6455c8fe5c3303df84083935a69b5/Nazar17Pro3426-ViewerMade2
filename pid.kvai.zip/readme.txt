####                        ####
#@@@@#                    #@@@@#
 #@@@@###   pid.kvai   ###@@@@#
   #@@@@#    __  __    #@@@@#
     ###### /  \/  \ ######
         ## |  pk  | ##
             \    /
               \/

pid.kvai.exe by Uuwai (kapi)
My first layered window GDI malware.

The name "kvai" is from the short video website kwai.com
And a heart with wings icon is from a random image I redraw using Paint and removed the background.

Inspiration from:
Tera Bonus (randomized GDI and math waves)
Hafnium, neptunium & quantizer (layered windows)
pid8 and pidh (name, idea, & bytebeats)
AiVDsDOsA.exe (tile GDI)
Solaris.exe & Laplace.exe (the bouncing shape)
mawaru.exe (rainbow and coloured Icons)
Sustain Epic.exe (RGBA image processing)
yortsedniw.exe & ColorCs.exe (moving windows)

This was created for artistic, analysis, entertainment and experimental purposes. Not for harmful and criminal purposes.
Destroying someone's Windows installation is not fun.
And the creator is not responsible.

4 days of development
Released on 2025/1/6 (YYYY/M/D)
After a break of 3 years, there is more break after this.

Programming Language: C#, assembly

Dependencies:
.NET Framework 4.0 (It should be preinstalled on Windows 8 and later)

Recommended OS: Windows XP
Windows Vista and later will work but it has a chance to crash.

Contains flashing lights!

What does it do:
1> Shows a warning 2 times, 3 times if dwm is running because it gives you choice to keep the layered windows.
2> Ovewrites the MBR From PhysicalDrive 0 to 24
3> Corrupts random files on the system32 folder (where Windows is installed on a drive letter, so not only C:\Windows\system32)
4> Opens a layered windows and setting itself to x=0 y=0(top left) and changing the size the same as the screen, the layered windows can be always at the top on the taskbar, menu, and start menu (except for Windows warning).
5> Shows and moves the windows and cursor, pressing keys including Locks, setting UI texts
6> Draws GDI, plays audio using bytebeat for 30 seconds & 20 times (30×20=600 seconds (10 minutes))
7> BSOD, but in a virtual machine, the window of the VM will close.
8> Boots into the overwritten MBR.

Tips:
Running with DWM will ask you to keep the layered windows to run even with DWM.
It will set as itself a critical process so killing it will cause BSOD.
The "has encountered a problem and needs to close" popup can be ignored.
The transparency key of the layered windows is black. So try to set your background to black.

Issues:
The layered window has a chance to be unresponsive
Has a chance to crash in less than 10 minutes


[PR]Recommended Channels

	NoFileFound
	https://www.youtube.com/@nofilefound9020

	danooct1
	https://www.youtube.com/@danooct1

	JGFT
	https://www.youtube.com/@JGFTChannel

	Enderman
	https://www.youtube.com/@Endermanch

	kapi2.0peys archive
	https://www.youtube.com/@kapi2.0peysarchive50

	kapi2.0peys
	https://www.youtube.com/channel/UCOjf5wIXdMZ1gFIdTG_JZPA

	AG5516
	https://www.youtube.com/@AG5516

	gabrik
	https://www.youtube.com/@labfoebaofi1847

	GetMBR
	https://www.youtube.com/@isolynx.getmbr

	pan koza 2
	https://www.youtube.com/@pankoza2

	JhoProツ
	https://www.youtube.com/@JhoPro

	wipet
	https://www.youtube.com/@wipet

	SleepMod
	https://www.youtube.com/@SleepMod

	ミスト
	https://www.youtube.com/@mist.malware

	さとるふぃっしゅ
	https://www.youtube.com/@satorufish

	Siam Alam
	https://www.youtube.com/@SiamAlamOfficial

	sarigatus
	https://www.youtube.com/@sarigatus

	CYBER SOLDIER
	https://www.youtube.com/@ClutterTech

	Clutter
	https://www.youtube.com/@clutter1952

	Itzsten
	https://www.youtube.com/@Itzsten

	aramaware
	https://www.youtube.com/@aramaware

	N17Pro3426
	https://www.youtube.com/@nazar7346