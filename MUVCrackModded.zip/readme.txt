MUVCrack.exe by Maxi2022gt
Remastered by Jazzstuff
This can harm your device!
Me and Maxi2022gt will not be responsible for anything caused.
Fun fact: If you press a key in the MBR, something happens! :)
So figure it out.