ninɘƧ.exe

Remade of ꝩabiꭋꟻ.exe by MCU
https://youtube.com/@mcu324
https://youtu.be/_fJZ1rrzhVk

Created it, because school is boring.
Will make a video about it in 2025.