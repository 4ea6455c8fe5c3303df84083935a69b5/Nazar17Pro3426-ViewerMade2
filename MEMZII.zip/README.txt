███╗░░░███╗███████╗███╗░░░███╗███████╗██╗██╗
████╗░████║██╔════╝████╗░████║╚════██║██║██║
██╔████╔██║█████╗░░██╔████╔██║░░███╔═╝██║██║
██║╚██╔╝██║██╔══╝░░██║╚██╔╝██║██╔══╝░░██║██║
██║░╚═╝░██║███████╗██║░╚═╝░██║███████╗██║██║
╚═╝░░░░░╚═╝╚══════╝╚═╝░░░░░╚═╝╚══════╝╚═╝╚═╝

Created by: Lizkit
Coding language: C++
Programs used: Dev-C++.
Supported OS: Windows XP and over.
Tested on: Windows XP 32-Bit.
This program will NOT work with previous versions.

This program is malicious and can cause significant damage to your system.
Upon executing it, you will be greeted with a warning to confirm your decision.

This program has flashing lights and loud noises, and is my personal spin off the classic MEMZ trojan, featuring new GDI payloads.
All credits go towards Leurak for creating the original masterpiece.

It's also recommended that the virtual machine or system is connected to the internet for the URLs to load successfully.

Enjoy :D

(I know the batch file doesn't create the .exe file, I was too lazy.)