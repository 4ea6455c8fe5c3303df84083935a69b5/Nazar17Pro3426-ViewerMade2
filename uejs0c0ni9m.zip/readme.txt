uejs0c0ni9m.exe

Made by UnknownException505 (@KewlThemes)
I made this malware in C++!

This is my new malware!

Hi, N17Pro3426, I am Wynn, yedb0y33k, Marlon2210, Comium92 and more!

 #    #

#      #
 ######