Dibromophosphine.exe by malsteve527

This is a malware and it will harm your computer.
Never run this on a real PC.
I'm NOT responsible for ANY damage.
The safe version will NOT do ANY damage.

Credits to wipet for the HSL.
Enjoy!