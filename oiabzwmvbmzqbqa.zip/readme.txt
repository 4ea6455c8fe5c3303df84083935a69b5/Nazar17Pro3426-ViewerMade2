oiabzwmvbmzqbqa.exe by Executioner
A malware developed the course of almost a day
The non-safety version will destroy your PC when you run it, I'm NOT responsible for ANY damages
Credits to ArTicZera and Wipet for the HSL
Creation date: May 27 2025
This malware contains flashing lights and earrape, NOT for epilepsy
Fun fact: oiabzwmvbmzqbqa means gastroenteritis in Caeser cipher
Fun fact 2: the MBR text comes from Glitter Force Doki Doki S2 E9, at the start of the episode





























































I know you will put this into the skidded folder in your trash ass database, FelloBoiYuuka, do something else instead of being a malware fan and leaking faces
Aero, stop simping for pankoza and check dates before commenting anything.