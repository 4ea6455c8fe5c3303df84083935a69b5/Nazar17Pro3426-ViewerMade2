█████ █████ █    █     ███   ███   ███  █████ █   █  ███   ███ █████  ███  █   █ █   █ █████ ████   ███  ████  ████   ███  █  █ █   █ █   █ █   █ ████  █████  ███  █   █  ███    █████ █   █ █████ █
█     █     █    █    █   █ █   █ █   █ █     █   █ █     █      █   █   █ █   █ █   █   █   █   █ █   █ █   █ █   █ █   █ █ █  █   █ ██  █ █   █ █   █   █   █   █ █   █ █       █      █ █  █     █
█████ █████ █    █    █   █ █     █   █ ███   █   █  ███  █      █   █   █ █   █ █████   █   ████  █   █ ████  ████  █   █ ██   █   █ █ █ █ █   █ ████    █   █   █ █   █  ███    █████   █   █████ █
█     █     █    █    █   █ █  ██ █   █ █     █   █     █ █      █   █   █ █   █ █   █   █   █     █   █ █     █     █   █ ██   █   █ █  ██ █   █ █ █     █   █   █ █   █     █   █      █ █  █     █
█████ █████ ████ ████  ███   ████  ███  █      ███   ███   ███ █████  ███   ███  █   █ █████ █      ███  █     █      ███  █ █   ███  █   █  ███  █  █  █████  ███   ███   ███  █ █████ █   █ █████ █
                                                                                                                                                                                                    █
█████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████ 1.2

My new malware!
Epilepsy and hearing damage warning!
OS support: possibly Windows Vista-11.
Destructive? No.
This is probably one of the best projects I've ever made!
Beta testers: Marlon2210 (thx for testing the second beta!)
Credits to ChatGPT for teaching me how to use radius and color pallette (I'm making better shaders now!)
Credits to RaduMinecraft: this user didn't really helped me, but I modified the code from Retrophilia and make the final shader.
N17Pro3426, Fienemann (Vexify), Marlon2210, ComiDaIcIcon (Comium92), NotCCR, cesiumxx (Mr. Super Buddy), ExpertWorks4417, Aung208, A Russian Guy, RaduMinecraft, Jern216, pankoza, fr4ctalz, PankozaTrojans, kapi2.0peys archive, Minhgotuknight19 (Tromiute), kapi2.5peys archive, VenraTech, The XJ (Abyss Guardian), yedboy33k and WinMalware, if you're reading this, then hi :) (I'mm try add more later.)
Anyways, good luck!
=============================
Changelog: Added a dynamic fake BSOD, so it's different depending on your Windows version.