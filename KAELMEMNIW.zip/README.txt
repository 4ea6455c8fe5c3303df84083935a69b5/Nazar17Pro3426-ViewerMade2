KAELMEMNIW.exe
-------------------------------------------------------------------------
A recreation of MEMOREZNIW.exe
Recreated by Uuwai (kapi)
MEMOREZNIW.exe belongs to NoFileFound
https://www.youtube.com/@nofilefound9020

Bytebeats used:
t*((t>>7|t>>11)&42) //8000hz
t*(t>>8|t<<5) //8000hz
2*t*(t>>8|t<<3) //11025hz
t*(4*t>>7|2*t>>11) //11025hz
t*(1*t>>10|2*t) //8000hz and 11025hz
t*(t>>8)*t^(t*t>>12) //8000hz